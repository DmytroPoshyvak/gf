
$(document).ready(function(){
    $('.autoplay').slick({
        autoplay: true,
        autoplaySpeed: 2000,
        infinite: true,
        pauseOnHover: false, // Disable pausing on hover
        pauseOnFocus: false, // Disable pausing on focus
    });
});
// $('.slider').slick({
//   prevArrow: "<img src='static/images/right-arrow (1).png' class='prev' alt='prev'>",
//   nextArrow: "<img src='static/images/right-arrow (1).png' class='next' alt='next'>",
// });
